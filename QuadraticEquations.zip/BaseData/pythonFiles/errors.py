"""Этот файл содержит кастомные ошибки, происходящие при решении"""


class Input_Error(Exception):
    pass


class Zero_Error(Exception):
    pass
